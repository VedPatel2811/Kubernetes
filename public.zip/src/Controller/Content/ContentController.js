import { solutions } from "../../Model/Content/ContentModel";

export const getSolutions = () => {
  return solutions;
};