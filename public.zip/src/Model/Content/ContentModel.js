export const solutions = [
  { id: 1, title: "Solution-1", meta: "GitHub • MM/DD/YYYY" },
  { id: 2, title: "Solution-2", meta: "GitHub • MM/DD/YYYY" },
  { id: 3, title: "Solution-3", meta: "GitHub • MM/DD/YYYY" },
  { id: 4, title: "Solution-4", meta: "GitHub • MM/DD/YYYY" },
  { id: 5, title: "Solution-5", meta: "GitHub • MM/DD/YYYY" },
  { id: 6, title: "Solution-6", meta: "GitHub • MM/DD/YYYY" },
  { id: 7, title: "Solution-7", meta: "GitHub • MM/DD/YYYY" },
  { id: 8, title: "Solution-8", meta: "GitHub • MM/DD/YYYY" },
];
