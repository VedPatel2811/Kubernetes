import { options } from "../../Model/Menu/MenuModel";

export const getSidebarOptions = () => {
  return options;
};
